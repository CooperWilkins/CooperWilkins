ALl you will have to do is do npm install (or npm i) then go to .env and config.js and edit to your needs
If you need help join our server and we can help
https://discord.gg/dBMNAGcafq